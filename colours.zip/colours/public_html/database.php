<?php
	$server = '192.168.56.2';
	$username = 'student';
	$password = 'student';
	$schema = 'colours';
	
	$pdo = new PDO('mysql:dbname=' . $schema . ';host=' . $server, $username, $password);
	
?>