<?php 
require 'database.php';
include 'head.php';
session_start();
?>
		<h2>Internet Programming</h2>

		<p>If you are seeing this page, you can now write files to the <code>public_html</code> directory and they will be accessible.</p>

		<p>Try the following:</p>

		<ol>
			<li>Create a new file <code>public_html/test.html</code></li>
			<li>Paste in the following code: 

			<pre><code>&lt;!DOCTYPE html&gt;
&lt;html&gt;
	&lt;head&gt;
		&lt;title&gt;My Web Page&lt;/title&gt;
	&lt;/head&gt;
	&lt;body&gt;
		Hello World!
	&lt;/body&gt;
&lt;/html&gt;
</code>
			</pre></li>

			<li>Navigate to <a href="http://<?= 
$_SERVER['HTTP_HOST']; ?>/test.html">http://<?= $_SERVER['HTTP_HOST']; 
?>/test.html</a> and you should see your web page</li>


		</ol>
<?php include "foot.php";?>