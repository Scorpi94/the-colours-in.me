<?php
require 'database.php';
include 'head.php';
session_start();
?>
	<?php
	if (isset($_POST['submit'])) {
		if ($_POST['username'] == :username && $_POST['password'] == :password) {
			$_SESSION['loggedin'] = true;	
		}
	}


	if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
	?>

	<form action="login.php" method="post">
			<label>Username</label>
			<input type="text" name="username" />
			<br/>
			<label>Password</label>
			<input type="password" name="password" />
			<br/>
			<input type="submit" name="submit" value="Log In" />
		</form>
<?php 
include 'foot.php';
?>